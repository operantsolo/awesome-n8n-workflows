# OperantSolo | Lead CSV import prep

- Built: yes
- Import-verified: yes
- Run-verified: yes
- Blocked: none for sample scope
- n8n server version: 2.48.7
- Execution IDs: 19
- Node versions in export: Run synthetic cases (manualTrigger 1), Load examples (code 2), Parse and triage lead rows (code 2)
- Credentials: None
- Actual: Local JavaScript checks passed for 4 cases. See actual-local.json for observed output.

One mixed CSV produces ready, invalid and duplicate buckets without creating contacts.

Run manually or replace the CSV text in Load examples. Fixed header order, comma delimiter, simple email screening, first valid row wins. Record numbers are logical CSV records. No historical matching.

## n8n evidence on 24 November 2026

Four rows matched. Mixed input produced one ready record, one invalid_email record and one duplicate. Header-only was empty, the malformed quote returned invalid_csv, and the trailing blank company stayed empty.
