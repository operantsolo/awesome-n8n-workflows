# OperantSolo | Sub-workflow return lab

- Built: yes
- Import-verified: yes
- Run-verified: yes
- Blocked: none for sample scope
- n8n server version: 2.48.7
- Execution IDs: parent 21, 23, 25; child 22, 24, 26
- Node versions in export: Run one child case (manualTrigger 1), Select child case (code 2), Call embedded child (executeWorkflow 1.2), Inspect child result (code 2)
- Credentials: None
- Actual: Local JavaScript checks passed for 3 cases. See actual-local.json for observed output.

The parent reports the child payload and whether it meets the contract.

Change scenario in Select child case and execute separately for valid, empty and malformed. Empty parent receipt is a prediction based on Always Output Data. Local checks ran child and guard JavaScript with an injected empty item for that case. Actual outputs are recorded below. Child versions: Execute Sub-workflow Trigger 1.1, Code 2. child.workflow.json is a readable companion. The parent uses the embedded copy.

## n8n evidence on 24 November 2026

Valid parent returned orderKey MOCK-001 and amount 42. Empty parent 23 showed received containing one empty object. Malformed parent 25 showed malformed status and the amount field. Edited the draft selector for each run, then restored valid.
