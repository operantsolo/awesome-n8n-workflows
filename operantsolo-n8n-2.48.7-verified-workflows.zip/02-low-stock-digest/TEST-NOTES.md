# OperantSolo | Low-stock digest

- Built: yes
- Import-verified: yes
- Run-verified: yes
- Blocked: none for sample scope
- n8n server version: 2.48.7
- Execution IDs: 18
- Node versions in export: Run synthetic cases (manualTrigger 1), Load examples (code 2), Group stock by SKU and location (code 2)
- Credentials: None
- Actual: Local JavaScript checks passed for 4 cases. See actual-local.json for observed output.

East reports one SKU at threshold while West stays out of the digest.

Run manually. Rows represent separate inventory bins, with maximum threshold honored per SKU/location and equality included. Invalid input yields review. Optional future adapter: Shopify Admin inventory reads.

## n8n evidence on 24 November 2026

Four rows matched. East RING reported available=3 and threshold=3, West was excluded, both empty fixtures returned empty arrays, and the invalid count returned review with invalid row 1.
