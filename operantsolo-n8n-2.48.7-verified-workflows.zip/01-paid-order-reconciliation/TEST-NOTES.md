# OperantSolo | Paid Order Reconciliation Lab

- Built: yes
- Import-verified: yes
- Run-verified: yes
- Blocked: none for sample scope
- n8n server version: 2.48.7
- Execution IDs: 16, 17
- Node versions in export: Run the lab (manualTrigger 1), Load examples or your snapshot (code 2), Replay mock paid deliveries (code 2), Compare source and destination (code 2), Read report and check examples (code 2), Start here (stickyNote 1), Use your own orders (stickyNote 1)
- Credentials: None
- Actual: Local JavaScript checks passed for 17 cases. See actual-local.json for observed output.

Two deliveries produce one mock record. A changed amount triggers amount_mismatch.

Reused the original 16-case comparison lab. Added a replay node and a seventeenth case that asserts one suppressed replay and one destination row. The mock store resets on every execution. A persistent unique key and atomic write would be needed for concurrent or cross-execution replay protection. Run manually and inspect Read report and check examples.

## n8n evidence on 24 November 2026

All 17 cases passed. The replay case reported replayCount=1 and destinationRows=1. The separate amount mismatch reported amount_mismatch.
