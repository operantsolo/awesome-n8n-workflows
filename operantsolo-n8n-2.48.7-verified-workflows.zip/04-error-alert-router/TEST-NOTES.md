# OperantSolo | Error alert router

- Built: yes
- Import-verified: yes
- Run-verified: yes
- Blocked: none for sample scope
- n8n server version: 2.48.7
- Execution IDs: 20
- Node versions in export: Run synthetic cases (manualTrigger 1), Load examples (code 2), Group and route failures (code 2)
- Credentials: None
- Actual: Local JavaScript checks passed for 4 cases. See actual-local.json for observed output.

Two identical failures become one alert group, and simulated primary failure exercises fallback.

Run manually. Grouping covers one supplied batch. The dead-letter result stays in node output. No Error Trigger or external delivery is configured. A future live adapter can aggregate Error Trigger events and persist unresolved alerts.

## n8n evidence on 24 November 2026

Four rows matched. Two failures coalesced into one group with count=2. Mock primary outage routed to fallback with SIMULATED_503. Both-down returned two dead-letter groups and no deliveries. Empty returned both arrays empty.
